package com.htportfolio.ai;

import java.util.Arrays;
import java.util.Locale;

/** One match. Decimal prices are exclusively HT exact-score markets (never FT). */
public final class Match {
    public String id, country, league, home, away, kickoff, status, oddsSource = "未获取";
    public final double[] odds = new double[3]; // 1-0, 0-0, 0-1
    public int homeId, awayId, leagueId, season;
    public int homeSamples, awaySamples;
    public double homeHalfFor, homeHalfAgainst, awayHalfFor, awayHalfAgainst;
    public double lambdaHome = Double.NaN, lambdaAway = Double.NaN;
    public String historyHome = "", historyAway = "", rankHome = "", rankAway = "";
    public boolean manual = false;
    public String aiNote = "", aiRisk = "";

    public Match(String id, String country, String league, String home, String away, String kickoff, String status) {
        this.id=id; this.country=country; this.league=league; this.home=home; this.away=away;
        this.kickoff=kickoff; this.status=status;
        Arrays.fill(odds, Double.NaN);
    }

    public boolean hasOdds() {
        for (double v : odds) if (!Double.isFinite(v) || v <= 1.0) return false;
        return true;
    }
    public boolean hasForm() { return Double.isFinite(lambdaHome) && Double.isFinite(lambdaAway); }
    public String label() { return home + " - " + away; }
    public String oddsLabel() {
        if (!hasOdds()) return "半场比分赔率缺失（请手动填入 Bet365 赔率）";
        return String.format(Locale.US,"1-0 %.2f  |  0-0 %.2f  |  0-1 %.2f",odds[0],odds[1],odds[2]);
    }
}
