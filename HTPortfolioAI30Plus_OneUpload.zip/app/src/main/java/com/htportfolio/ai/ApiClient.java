package com.htportfolio.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Football API-Sports for fixtures/history; optional Bet365-specific provider for HT exact-score odds. */
public final class ApiClient {
    private static final String FOOTBALL="https://v3.football.api-sports.io";
    private static final String BET365="https://api.odds-data-api.com";
    private final String footballKey, bet365Token;
    private final Map<String,String> standings=new HashMap<>();
    private final Map<String,String> bet365Ids=new HashMap<>();
    private final Set<String> occupiedBet365Ids=new HashSet<>();
    private String bet365IndexDate="";
    private int bookmakerId=-1;
    private boolean bookmakerChecked=false;
    public interface Log { void message(String s); }
    public ApiClient(String footballKey,String bet365Token) {
        this.footballKey=footballKey.trim();this.bet365Token=bet365Token.trim();
    }
    public static JSONObject request(String url,String footballKey) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(9000);c.setReadTimeout(11000);c.setRequestProperty("Accept","application/json");
        if(footballKey!=null && !footballKey.isEmpty())c.setRequestProperty("x-apisports-key",footballKey);
        try {
            int status=c.getResponseCode(); InputStream in=status>=400?c.getErrorStream():c.getInputStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
            if(in!=null)try(in){while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>3_000_000)throw new Exception("API 响应超过3MB");}}
            String data=out.toString(StandardCharsets.UTF_8.name());
            if(status>=400)throw new Exception("HTTP "+status+" "+data.substring(0,Math.min(150,data.length())));
            JSONObject parsed=new JSONObject(data);
            if(parsed.has("errors")) {
                Object e=parsed.opt("errors");
                if(e instanceof JSONArray && ((JSONArray)e).length()>0) throw new Exception("Football API 错误："+e);
                if(e instanceof JSONObject && ((JSONObject)e).length()>0) throw new Exception("Football API 错误："+e);
            }
            if(parsed.has("success") && parsed.optInt("success",1)==0)throw new Exception("赔率 API："+parsed.optString("error","请求失败"));
            return parsed;
        } finally { c.disconnect(); }
    }
    private JSONObject football(String path) throws Exception {return request(FOOTBALL+path,footballKey);}
    private JSONObject bet(String path) throws Exception {return request(BET365+path+(path.contains("?")?"&":"?")+"token="+enc(bet365Token),null);}
    private static String enc(String v){try{return java.net.URLEncoder.encode(v,"UTF-8");}catch(Exception e){return v;}}
    private static String normalize(String s){
        String n=Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);
        return n.replaceAll("(?i)\\b(fc|cf|afc|sc|club|the|fk|ac)\\b","").replaceAll("[^a-z0-9]","").trim();
    }
    private static double number(Object value){try{return Double.parseDouble(String.valueOf(value));}catch(Exception e){return Double.NaN;}}
    private static boolean validScore(JSONObject obj){return obj!=null && !obj.isNull("home")&&!obj.isNull("away");}
    public List<Match> fixtures(String date,int maxPool,Log log) throws Exception {
        if(footballKey.isEmpty())throw new Exception("请填写 Football API-Sports Key");
        JSONArray rows=football("/fixtures?date="+enc(date)+"&timezone=America%2FArgentina%2FBuenos_Aires").optJSONArray("response");
        if(rows==null)throw new Exception("未取得比赛列表");
        List<Match> candidates=new ArrayList<>();
        for(int i=0;i<rows.length();i++){
            JSONObject item=rows.optJSONObject(i);if(item==null)continue;
            JSONObject fi=item.optJSONObject("fixture"),teams=item.optJSONObject("teams"),league=item.optJSONObject("league");
            if(fi==null||teams==null||league==null)continue;
            String st=fi.optJSONObject("status")==null?"":fi.optJSONObject("status").optString("short","");
            if(!"NS".equals(st)&&!"TBD".equals(st))continue;
            String leagueName=league.optString("name",""); String country=league.optString("country","");
            String l=(leagueName+" "+country).toLowerCase(Locale.ROOT);
            if(l.matches(".*(friendly|friendlies|amistos|u[0-9][0-9]|youth|junior|reserve|esoccer|e-soccer).*"))continue;
            JSONObject h=teams.optJSONObject("home"),a=teams.optJSONObject("away");if(h==null||a==null)continue;
            String when=fi.optString("date","");
            Match m=new Match(String.valueOf(fi.optLong("id")),country,leagueName,h.optString("name"),a.optString("name"),when,st);
            m.homeId=h.optInt("id");m.awayId=a.optInt("id");m.leagueId=league.optInt("id");m.season=league.optInt("season");
            candidates.add(m);
        }
        // Stable sort: more established competitions get priority before API expensive history calls.
        candidates.sort(Comparator.comparingInt((Match m)->importance(m.league,m.country)).reversed().thenComparing(m->m.kickoff));
        log.message("共找到 "+candidates.size()+" 场未开赛比赛；开始抽取历史数据（免费套餐可能限制请求量）");
        return new ArrayList<>(candidates.subList(0,Math.min(candidates.size(),Math.max(8,maxPool))));
    }
    private static int importance(String league,String country){
        String s=(league+" "+country).toLowerCase(Locale.ROOT);
        if(s.contains("premier league")||s.contains("la liga")||s.contains("serie a")||s.contains("bundesliga")||s.contains("ligue 1"))return 5;
        if(s.contains("champions")||s.contains("europa league")||s.contains("libertadores")||s.contains("sudamericana"))return 5;
        if(s.contains("primera")||s.contains("superliga")||s.contains("eredivisie")||s.contains("championship"))return 4;
        if(s.contains("cup")||s.contains("copa")||s.contains("reserve")||s.contains("women"))return 1;
        return 2;
    }
    public void enrichHistory(Match m) throws Exception {
        history(m,m.homeId,true);history(m,m.awayId,false);
        Engine.estimateForm(m);
        String ranks=standings.get(m.leagueId+":"+m.season);
        // Standings fetched per-league later in enrichStandings (avoid 1 call per match).
    }
    private void history(Match m,int teamId,boolean homeTeam) throws Exception {
        JSONArray arr=football("/fixtures?team="+teamId+"&last=12").optJSONArray("response");
        if(arr==null)return;
        int count=0;double gf=0,ga=0;StringBuilder history=new StringBuilder();
        for(int i=0;i<arr.length()&&count<7;i++){
            JSONObject f=arr.optJSONObject(i);if(f==null)continue;
            JSONObject fix=f.optJSONObject("fixture"),teams=f.optJSONObject("teams"),scores=f.optJSONObject("score");
            if(fix==null||teams==null||scores==null)continue;
            String st=fix.optJSONObject("status")==null?"":fix.optJSONObject("status").optString("short");
            if(!"FT".equals(st)&&!"AET".equals(st)&&!"PEN".equals(st))continue;
            JSONObject ht=scores.optJSONObject("halftime");if(!validScore(ht))continue;
            JSONObject home=teams.optJSONObject("home");if(home==null)continue;
            boolean ownHome=home.optInt("id")==teamId;
            int g=ht.optInt(ownHome?"home":"away"),conceded=ht.optInt(ownHome?"away":"home");
            gf+=g;ga+=conceded;count++;
            if(history.length()>0)history.append("  ");
            history.append(g).append("-").append(conceded);
        }
        if(homeTeam){m.homeSamples=count;m.homeHalfFor=count==0?0:gf/count;m.homeHalfAgainst=count==0?0:ga/count;m.historyHome=history.toString();}
        else{m.awaySamples=count;m.awayHalfFor=count==0?0:gf/count;m.awayHalfAgainst=count==0?0:ga/count;m.historyAway=history.toString();}
    }
    public void enrichStandings(Match m) {
        try {
            String cacheKey=m.leagueId+":"+m.season;
            if(!standings.containsKey(cacheKey)) {
                JSONObject data=football("/standings?league="+m.leagueId+"&season="+m.season);
                standings.put(cacheKey,data.toString());
            }
            JSONObject result=new JSONObject(standings.get(cacheKey));
            JSONArray r=result.optJSONArray("response");if(r==null||r.length()==0)return;
            JSONArray standingsGroups=r.optJSONObject(0).optJSONObject("league").optJSONArray("standings");if(standingsGroups==null)return;
            for(int a=0;a<standingsGroups.length();a++) {
                JSONArray rows=standingsGroups.optJSONArray(a);if(rows==null)continue;
                for(int i=0;i<rows.length();i++) {
                    JSONObject row=rows.optJSONObject(i),team=row==null?null:row.optJSONObject("team");if(team==null)continue;
                    if(team.optInt("id")==m.homeId)m.rankHome=String.valueOf(row.optInt("rank"));
                    if(team.optInt("id")==m.awayId)m.rankAway=String.valueOf(row.optInt("rank"));
                }
            }
        }catch(Exception ignored) { /* not all cups expose tables */ }
    }
    private int bookmaker() throws Exception {
        if(bookmakerChecked)return bookmakerId;
        bookmakerChecked=true;
        JSONObject data=football("/odds/bookmakers?search=Bet365");JSONArray a=data.optJSONArray("response");
        if(a==null) return -1;
        for(int i=0;i<a.length();i++){
            JSONObject row=a.optJSONObject(i);
            if(row!=null&&row.optString("name").replace(" ","").equalsIgnoreCase("bet365"))return bookmakerId=row.optInt("id");
        }
        return -1;
    }
    public boolean retrieveOdds(Match m,Log log) throws Exception {
        if(!bet365Token.isEmpty()){
            try { if(retrieveDirectBet365Odds(m))return true; }
            catch(Exception e){log.message("Bet365 数据获取失败："+e.getMessage());}
        }
        // API-Sports bookmaker filter; ONLY accept explicit HT Correct Score market from Bet365.
        int bk=bookmaker(); if(bk<=0)return false;
        JSONArray arr=football("/odds?fixture="+enc(m.id)+"&bookmaker="+bk).optJSONArray("response");
        if(arr==null)return false;
        for(int i=0;i<arr.length();i++){
            JSONObject node=arr.optJSONObject(i);if(node==null)continue;
            JSONArray bookies=node.optJSONArray("bookmakers");if(bookies==null)continue;
            for(int j=0;j<bookies.length();j++){
                JSONObject book=bookies.optJSONObject(j);if(book==null||!book.optString("name").equalsIgnoreCase("Bet365"))continue;
                JSONArray bets=book.optJSONArray("bets");if(bets==null)continue;
                for(int b=0;b<bets.length();b++){
                    JSONObject bet=bets.optJSONObject(b);if(bet==null||!isHalfCorrectScoreMarket(bet.optString("name")))continue;
                    JSONArray val=bet.optJSONArray("values");double[] odds=new double[]{Double.NaN,Double.NaN,Double.NaN};
                    if(val!=null)for(int k=0;k<val.length();k++){
                        JSONObject p=val.optJSONObject(k);if(p==null)continue;
                        int idx=scoreIndex(p.optString("value"));if(idx>=0)odds[idx]=number(p.optString("odd"));
                    }
                    if(assign(m,odds,"Bet365 / API-Sports（半场正确比分）"))return true;
                }
            }
        }
        return false;
    }
    private void indexDirectBet365(String date) throws Exception {
        if(date.equals(bet365IndexDate))return;
        bet365Ids.clear();occupiedBet365Ids.clear();bet365IndexDate=date;
        for(int page=1;page<=15;page++){
            JSONObject doc=bet("/v3/events/upcoming?sport_id=1&skip_esports=1&day="+date.replace("-","")+"&page="+page);
            JSONArray rows=doc.optJSONArray("results");if(rows==null||rows.length()==0)break;
            for(int i=0;i<rows.length();i++){
                JSONObject e=rows.optJSONObject(i);if(e==null)continue;
                JSONObject home=e.optJSONObject("home"),away=e.optJSONObject("away");if(home==null||away==null)continue;
                String key=normalize(home.optString("name"))+"|"+normalize(away.optString("name"));
                long kickoff=(long)number(e.optString("time"));
                String value=e.optString("bet365_id","");
                if(!value.isEmpty())bet365Ids.put(key+"|"+kickoff,value);
            }
            JSONObject pager=doc.optJSONObject("pager");
            if(pager==null)break;
            int total=pager.optInt("total",page*rows.length()),perPage=Math.max(1,pager.optInt("per_page",rows.length()));
            if(page>=Math.ceil(total/(double)perPage))break;
        }
    }
    private boolean retrieveDirectBet365Odds(Match m) throws Exception {
        String date=m.kickoff.length()>=10?m.kickoff.substring(0,10):LocalDate.now().toString();
        try { date=java.time.OffsetDateTime.parse(m.kickoff).toInstant()
                   .atZone(ZoneId.of("UTC")).toLocalDate().toString(); }catch(Exception ignored){}
        indexDirectBet365(date);
        String target=normalize(m.home)+"|"+normalize(m.away)+"|";
        long ts=0;try{ts=java.time.OffsetDateTime.parse(m.kickoff).toEpochSecond();}catch(Exception ignored){}
        String fi=null;long bestDistance=Long.MAX_VALUE;
        for(Map.Entry<String,String> kv:bet365Ids.entrySet()){
            if(!kv.getKey().startsWith(target))continue;
            long time=Long.parseLong(kv.getKey().substring(target.length()));long delta=Math.abs(time-ts);
            if(delta<=5400 && delta<bestDistance && !occupiedBet365Ids.contains(kv.getValue())){fi=kv.getValue();bestDistance=delta;}
        }
        if(fi==null)return false;
        occupiedBet365Ids.add(fi);
        JSONObject doc=bet("/v4/bet365/prematch?FI="+enc(fi));
        JSONArray r=doc.optJSONArray("results");if(r==null||r.length()==0)return false;
        JSONObject event=r.optJSONObject(0);if(event==null)return false;
        // Explicit market verification: ignore Full Time 'correct_score' and Half Time Result (1X2).
        for(String section:new String[]{"half","main","others"}){
            Object obj=event.opt(section);
            if(obj instanceof JSONObject){
                JSONObject group=(JSONObject)obj;JSONObject sp=group.optJSONObject("sp");if(sp==null)continue;
                java.util.Iterator<String> keys=sp.keys();while(keys.hasNext()){
                    String key=keys.next();JSONObject market=sp.optJSONObject(key);if(market==null)continue;
                    if(!isHalfCorrectScoreMarket(key)&&!isHalfCorrectScoreMarket(market.optString("name")))continue;
                    if(readMarket(m,market,"Bet365 / Odds Data API（半场正确比分）"))return true;
                }
            } else if(obj instanceof JSONArray){
                JSONArray others=(JSONArray)obj;
                for(int a=0;a<others.length();a++){
                    JSONObject market=others.optJSONObject(a);if(market!=null&&isHalfCorrectScoreMarket(market.optString("name"))&&readMarket(m,market,"Bet365 / Odds Data API（半场正确比分）"))return true;
                }
            }
        }
        return false;
    }
    private static boolean readMarket(Match m,JSONObject market,String source){
        JSONArray rows=market.optJSONArray("odds");if(rows==null)return false;
        double[] odds={Double.NaN,Double.NaN,Double.NaN};
        for(int i=0;i<rows.length();i++){
            JSONObject row=rows.optJSONObject(i);if(row==null)continue;
            if(row.optInt("SU",0)==1)continue;
            int idx=scoreIndex(row.optString("name"));if(idx>=0)odds[idx]=number(row.optString("odds"));
        }
        return assign(m,odds,source);
    }
    public static boolean isHalfCorrectScoreMarket(String s){
        String x=s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]"," ").trim().replaceAll(" +"," ");
        return (x.contains("correct score")||x.contains("exact score"))&&
          (x.contains("half")||x.contains("1st")||x.contains("first"));
    }
    public static int scoreIndex(String name){
        String norm=name.trim().replace('：',':').replace('–','-').replace('—','-');
        java.util.regex.Matcher mt=java.util.regex.Pattern.compile("(?<!\\d)([01])\\s*[-:]\\s*([01])(?!\\d)").matcher(norm);
        if(!mt.find())return -1;
        int h=Integer.parseInt(mt.group(1)),a=Integer.parseInt(mt.group(2));
        if(h==1&&a==0)return 0;if(h==0&&a==0)return 1;if(h==0&&a==1)return 2;return -1;
    }
    private static boolean assign(Match m,double[] odds,String source){
        for(double v:odds)if(!Double.isFinite(v)||v<=1)return false;
        System.arraycopy(odds,0,m.odds,0,3);m.oddsSource=source;return true;
    }
}
