package com.htportfolio.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(14,22,29), CARD=Color.rgb(29,43,51), ACCENT=Color.rgb(53,222,196);
    private static final int TEXT=Color.WHITE, MUTED=Color.rgb(168,189,198), WARN=Color.rgb(255,198,93);
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private LinearLayout root, fixturesContainer, summaryContainer, scenarioContainer;
    private EditText footballKey,bet365Key,aiKey,dateInput,targetInput,stakeInput,budgetInput,minOddsInput,maxOddsInput;
    private CheckBox allOddsCheck;
    private Engine.OddsFilter oddsFilter = new Engine.OddsFilter(3.0,Double.POSITIVE_INFINITY,false);
    private TextView status,scanTitle;private Button scanButton,autoFitButton;
    private int insuranceCount=2;
    private List<Match> scanned=new ArrayList<>();
    private List<Engine.Selection> selected=new ArrayList<>();
    private Engine.Portfolio portfolio;private boolean demo=false;
    private int target=20;private double baseStake=10000,budget=300000;
    @Override public void onCreate(Bundle bundle){super.onCreate(bundle);buildUi();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(16),dp(14),dp(30));scroll.addView(root);
        setContentView(scroll);
        title(root,"HT PORTFOLIO AI 30+",23,ACCENT);
        label(root,"赛前概率 → Bet365 半场比分赔率 → 主单/保险 → 多场组合盈亏",13,MUTED);
        section(root,"参数设置");
        dateInput=field(root,"比赛日期 YYYY-MM-DD",LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires")).toString(),false);
        targetInput=field(root,"计划场数（20 / 30 / 50，可修改）","20",false);
        stakeInput=field(root,"每场主单金额","10000",false);
        budgetInput=field(root,"资金预算（可为空，先自动计算总投入）","300000",false);
        section(root,"Bet365 上半场正确比分赔率筛选（可输入）");
        minOddsInput=field(root,"赔率下限（严格大于），默认 3.0","3",false);
        maxOddsInput=field(root,"赔率上限（小于等于），留空代表不限制","",false);
        allOddsCheck=new CheckBox(this);allOddsCheck.setText("主单、保险单都必须在赔率范围内（未勾选仅筛主单）");
        allOddsCheck.setTextColor(TEXT);allOddsCheck.setTextSize(13);
        root.addView(allOddsCheck);
        label(root,"示例：下限3、上限8 → 接受 3 < 赔率 ≤ 8；3.00 不通过。修改条件后再次点击扫描或“按当前赔率条件重新计算”。",12,MUTED);
        button(root,"按当前赔率条件重新计算",()->recompute(true));
        section(root,"接口 Key（仅本次使用，不写入本机存储）");
        footballKey=field(root,"Football API-Sports x-apisports-key","",true);
        bet365Key=field(root,"Bet365 独立赔率 API token（可选）","",true);
        aiKey=field(root,"OpenAI API Key（可选，AI风险复核）","",true);
        label(root,"Football API-Sports 提供赛程/近7场；赔率优先使用 Bet365 专用数据源，其次仅在 API-Sports 存在 Bet365 半场正确比分时使用。缺赔率则允许手动录入，不会伪造。",12,MUTED);
        LinearLayout hedgeRow=horizontal(root);
        Button one=button(hedgeRow,"1 张保险",()->{insuranceCount=1;recompute(false);});
        Button two=button(hedgeRow,"2 张保险",()->{insuranceCount=2;recompute(false);});
        scanButton=button(root,"开始扫描比赛并计算组合",this::scan);
        Button demoButton=button(root,"试算演示（虚构比赛与赔率）",this::loadDemo);
        demoButton.setTextColor(WARN);
        status=label(root,"准备就绪。先填写 Football API Key，扫描后会提示每场赔率是否齐全。",13,MUTED);
        scanTitle=label(root,"",13,ACCENT);
        section(root,"组合预算与盈利概率");
        summaryContainer=vertical(root);
        autoFitButton=button(root,"按总预算自动调整每场主单",this::autoFit);
        autoFitButton.setEnabled(false);
        section(root,"命中张数 × 组合盈亏范围");
        scenarioContainer=vertical(root);
        section(root,"赛事列表（可修改缺失的 Bet365 半场赔率）");
        fixturesContainer=vertical(root);
        label(root,"风险提示：历史7场的半场进球是概率估计，不是xG；本App只做研究与算账，不下注。模拟概率假设各场独立，现实存在相关性及模型偏差。",12,WARN);
        updateInsuranceButtons(one,two);
        one.setOnClickListener(v->{insuranceCount=1;updateInsuranceButtons(one,two);recompute(false);});
        two.setOnClickListener(v->{insuranceCount=2;updateInsuranceButtons(one,two);recompute(false);});
    }
    private void updateInsuranceButtons(Button one,Button two){one.setText(insuranceCount==1?"● 1 张保险":"○ 1 张保险");two.setText(insuranceCount==2?"● 2 张保险":"○ 2 张保险");}
    private LinearLayout vertical(LinearLayout parent){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);parent.addView(l);return l;}
    private LinearLayout horizontal(LinearLayout parent){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);parent.addView(l);return l;}
    private TextView label(LinearLayout parent,String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);v.setPadding(dp(4),dp(5),dp(4),dp(5));parent.addView(v);return v;}
    private void title(LinearLayout parent,String text,int size,int color){TextView t=label(parent,text,size,color);t.setTypeface(null,1);}
    private void section(LinearLayout parent,String text){TextView t=label(parent,"▰  "+text,18,ACCENT);t.setPadding(dp(3),dp(16),dp(3),dp(8));t.setTypeface(null,1);}
    private EditText field(LinearLayout parent,String hint,String initial,boolean secret){
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint(hint);input.setText(initial);input.setTextColor(TEXT);input.setHintTextColor(MUTED);
        if(secret)input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setTextSize(15);input.setPadding(dp(9),dp(8),dp(9),dp(8));
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,dp(47));params.bottomMargin=dp(5);parent.addView(input,params);return input;
    }
    private Button button(LinearLayout parent,String text,Runnable click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextColor(TEXT);b.setTextSize(14);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(parent.getOrientation()==LinearLayout.HORIZONTAL?0:-1,dp(47),parent.getOrientation()==LinearLayout.HORIZONTAL?1:0);
        params.setMargins(dp(2),dp(5),dp(2),dp(5));parent.addView(b,params);b.setOnClickListener(v->click.run());return b;
    }
    private String val(EditText e){return e.getText().toString().trim();}
    private void parseParameters(){
        target=(int)parse(val(targetInput),20);target=Math.max(1,Math.min(80,target));
        baseStake=parse(val(stakeInput),10000);if(baseStake<=0||baseStake>10_000_000)throw new IllegalArgumentException("主单金额需大于0且小于1千万");
        budget=val(budgetInput).isEmpty()?0:parse(val(budgetInput),0);if(budget<0)throw new IllegalArgumentException("预算不能小于零");
        double minOdds=parse(val(minOddsInput),3.0);
        double maxOdds=val(maxOddsInput).isEmpty()?Double.POSITIVE_INFINITY:parse(val(maxOddsInput),Double.POSITIVE_INFINITY);
        oddsFilter=new Engine.OddsFilter(minOdds,maxOdds,allOddsCheck.isChecked());
        if(val(dateInput).length()!=10)throw new IllegalArgumentException("请输入 YYYY-MM-DD 格式日期");
        LocalDate.parse(val(dateInput),DateTimeFormatter.ISO_DATE);
    }
    private static double parse(String s,double fallback){try{return s.isEmpty()?fallback:Double.parseDouble(s.replace(",",""));}catch(Exception e){throw new IllegalArgumentException("输入的金额或场数不是有效数字："+s);}}
    private void setStatus(String s){ui.post(()->status.setText(s));}
    private void scan(){
        try{parseParameters();}catch(Exception e){error(e.getMessage());return;}
        if(val(footballKey).isEmpty()){error("请填写 Football API Key；也可先点击演示查看完整算账界面");return;}
        demo=false;scanned=new ArrayList<>();selected.clear();summaryContainer.removeAllViews();fixturesContainer.removeAllViews();scenarioContainer.removeAllViews();
        scanButton.setEnabled(false);
        String key=val(footballKey),oddsToken=val(bet365Key),openai=val(aiKey),date=val(dateInput);
        final int n=target;
        worker.execute(()->{
            try {
                ApiClient api=new ApiClient(key,oddsToken);
                List<Match> upcoming=api.fixtures(date,Math.max(24,Math.min(160,(int)Math.ceil(n*1.6))),this::setStatus);
                List<Match> processed=new ArrayList<>();int oddsPresent=0;
                for(Match m:upcoming){
                    if(Thread.currentThread().isInterrupted())return;
                    int i=processed.size()+1;
                    setStatus("获取球队最近7场与 Bet365 赔率... "+i+"/"+upcoming.size()+"\n"+m.label());
                    try {api.enrichHistory(m);}catch(Exception ex){m.aiNote="历史接口异常："+ex.getMessage();}
                    try {api.enrichStandings(m);}catch(Exception ignored){}
                    try {if(api.retrieveOdds(m,this::setStatus))oddsPresent++;}catch(Exception ex){m.aiNote="赔率接口异常："+ex.getMessage();}
                    processed.add(m);
                }
                String aiMessage="";
                try {aiMessage=AiService.audit(openai,processed);}catch(Exception ex){aiMessage="AI 审计失败，保留基础数学模型："+ex.getMessage();}
                final int count=oddsPresent;final String finalAi=aiMessage;
                ui.post(()->{
                    scanned=processed;setStatus("已核对 "+processed.size()+" 场，有完整半场赔率 "+count+" 场。"+finalAi);
                    recompute(false);renderFixtures();scanButton.setEnabled(true);
                });
            }catch(Exception ex){ui.post(()->{scanButton.setEnabled(true);error(ex.getMessage());});}
        });
    }
    private void recompute(boolean refreshList){
        try{parseParameters();}catch(Exception e){setStatus("参数错误："+e.getMessage());return;}
        List<Engine.Selection> preliminary=Engine.selectTop(scanned,baseStake,insuranceCount,target,oddsFilter);
        selected=preliminary;portfolio=Engine.portfolio(selected,budget);
        renderSummary();renderScenarios();
        if(refreshList)renderFixtures();
    }
    private void renderSummary(){
        summaryContainer.removeAllViews();autoFitButton.setEnabled(!selected.isEmpty()&&budget>0);
        if(scanned.isEmpty()){label(summaryContainer,"尚未分析比赛。",14,MUTED);return;}
        int withOdds=0,withModel=0,pass=0;
        for(Match m:scanned){if(m.hasOdds())withOdds++;if(m.hasForm())withModel++;Engine.Selection s=Engine.choose(m,baseStake,insuranceCount,oddsFilter);if(s!=null&&"PASS".equals(s.grade))pass++;}
        title(summaryContainer,(demo?"【演示数据】":"【API 数据】")+" 已观察 "+scanned.size()+" 场 | 模型有效 "+withModel+" 场 | 半场赔率完整 "+withOdds+" 场 | 入选 "+selected.size()+" / "+target+" 场",15,TEXT);
        label(summaryContainer,"当前赔率过滤："+oddsFilter.description()+"（Bet365 半场正确比分，十进制）",13,ACCENT);
        if(selected.isEmpty()){label(summaryContainer,"没有达到 A/B 级的数据与赔率组合。PASS：不为了凑够场数而下注；也可能是赔率缺失，请手工输入确认的半场报价。",14,WARN);return;}
        label(summaryContainer,"每场主单 "+money(baseStake)+"，保险 "+insuranceCount+" 张；主单总额 "+money(baseStake*selected.size())+"，保险总额 "+money(portfolio.total-baseStake*selected.size()),14,TEXT);
        title(summaryContainer,"实际组合总投入 "+money(portfolio.total),21,ACCENT);
        if(budget>0)label(summaryContainer,"预算 "+money(budget)+" | "+(portfolio.total>budget?"超预算 "+money(portfolio.total-budget):"剩余预算 "+money(budget-portfolio.total)),16,portfolio.total>budget?WARN:ACCENT);
        label(summaryContainer,"模型期望净收益 "+money(portfolio.expectation)+" | 预期 ROI "+pct(portfolio.expectation/portfolio.total),15,TEXT);
        label(summaryContainer,"所有其他比分："+money(portfolio.worstCase)+" | 理论最好："+money(portfolio.bestCase),15,WARN);
        label(summaryContainer,"蒙特卡洛估计组合不亏概率 "+pct(portfolio.estimatedBreakevenChance)+"（12,000次、独立比赛假设）",15,TEXT);
        label(summaryContainer,"模拟净收益分位 P05 / P50 / P95："+money(portfolio.p05)+" / "+money(portfolio.p50)+" / "+money(portfolio.p95),13,MUTED);
        if(budget>0)label(summaryContainer,"预算粗略可承受的主单≈"+money(portfolio.suggestedMain)+"/场（下面按钮进行精确重算）",14,MUTED);
        label(summaryContainer,"保险金额已使保险比分命中时本场尽量不亏；但如果是其他比分，本场所有本金损失。赔率/概率估计变化会影响结果。",13,WARN);
        Button copy=button(summaryContainer,"复制当前组合与详细盈亏",this::copySummary);copy.setTextColor(ACCENT);
    }
    private void renderScenarios(){
        scenarioContainer.removeAllViews();
        if(portfolio==null||portfolio.n==0)return;
        label(scenarioContainer,"精确穷举动态规划：在“主单中m场、保险中b场”条件下，计算真实金额的最小/最大组合净盈亏。相同命中张数也可能盈利不同。",13,MUTED);
        int n=portfolio.n;
        for(int main=0;main<=n;main++){
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;int guaranteed=-1,possible=-1;
            for(int hedge=0;hedge<=n-main;hedge++){
                double lo=portfolio.min(main,hedge),hi=portfolio.max(main,hedge);
                if(Double.isFinite(lo)){min=Math.min(min,lo);max=Math.max(max,hi);if(guaranteed<0&&lo>=-0.01)guaranteed=hedge;if(possible<0&&hi>=-0.01)possible=hedge;}
            }
            label(scenarioContainer,String.format(Locale.US,"主单 %2d 场｜盈亏 %s ～ %s｜保险至少 %s / 可能 %s 场保本",main,money(min),money(max),guaranteed<0?"无":String.valueOf(guaranteed),possible<0?"无":String.valueOf(possible)),12,(main%2==0)?TEXT:MUTED);
        }
        Button matrix=button(scenarioContainer,"展开全部命中组合盈亏矩阵（含保险命中数）",this::showMatrix);matrix.setTextColor(ACCENT);
    }
    private void showMatrix(){
        if(portfolio==null)return;
        ScrollView s=new ScrollView(this);TextView table=new TextView(this);table.setTextColor(TEXT);table.setTextSize(12);table.setPadding(dp(12),dp(10),dp(12),dp(10));
        StringBuilder sb=new StringBuilder("主单命中 / 保险命中 → 最小净盈亏 ~ 最大净盈亏\n\n");
        for(int m=0;m<=portfolio.n;m++)for(int b=0;b<=portfolio.n-m;b++){
            double lo=portfolio.min(m,b),hi=portfolio.max(m,b);
            if(Double.isFinite(lo))sb.append(m).append(" / ").append(b).append(" → ").append(money(lo)).append(" ~ ").append(money(hi)).append("\n");
        }
        table.setText(sb.toString());s.addView(table);
        new AlertDialog.Builder(this).setTitle("组合盈亏保本完整情景表").setView(s).setPositiveButton("关闭",null).setNeutralButton("复制",(d,w)->clipboard(sb.toString())).show();
    }
    private void renderFixtures(){
        fixturesContainer.removeAllViews();if(scanned.isEmpty())return;
        int i=0;
        for(Match m:scanned){
            Engine.Selection s=null;for(Engine.Selection sel:selected)if(sel.match==m){s=sel;break;}
            LinearLayout box=vertical(fixturesContainer);box.setBackgroundColor(CARD);box.setPadding(dp(10),dp(7),dp(10),dp(12));
            LinearLayout.LayoutParams pp=(LinearLayout.LayoutParams)box.getLayoutParams();pp.bottomMargin=dp(9);box.setLayoutParams(pp);
            title(box,(++i)+". "+m.label(),15,TEXT);
            label(box,m.country+" / "+m.league+" | "+m.kickoff+" | 赛前",12,MUTED);
            label(box,m.oddsLabel()+"\n赔率来源："+(demo?"虚构示例":m.oddsSource),13,m.hasOdds()?ACCENT:WARN);
            if(m.hasForm()){
                double[] p=Engine.probabilities(m.lambdaHome,m.lambdaAway);
                label(box,"概率 1-0 "+pct(p[0])+"｜0-0 "+pct(p[1])+"｜0-1 "+pct(p[2])+"｜其他 "+pct(p[3]),12,TEXT);
                if(m.hasOdds())label(box,"赔率单项期望差(p×赔率−1)：1-0 "+pct(p[0]*m.odds[0]-1)+"｜0-0 "+pct(p[1]*m.odds[1]-1)+"｜0-1 "+pct(p[2]*m.odds[2]-1),12,MUTED);
            } else label(box,"样本不足4场/队，概率模型无法有效运行",12,WARN);
            if(s!=null){
                title(box,"【"+s.grade+" 候选】主单 "+Engine.SCORES[s.main]+" "+money(s.stakes[s.main])+" ｜本场投入 "+money(s.invested),14,ACCENT);
                for(int score=0;score<3;score++)if(score!=s.main&&s.stakes[score]>0)label(box,"保险 "+Engine.SCORES[score]+" "+money(s.stakes[score]),12,MUTED);
                label(box,"比分命中净盈亏：1-0 "+money(s.profits[0])+" / 0-0 "+money(s.profits[1])+" / 0-1 "+money(s.profits[2])+" / 其他 "+money(s.profits[3]),12,TEXT);
                label(box,s.why,12,MUTED);
            }else{
                Engine.Selection s2=Engine.choose(m,baseStake,insuranceCount,oddsFilter);
                String reason=!m.hasOdds()?"未取得半场赔率":!m.hasForm()?"历史样本不足":s2==null?"赔率范围或数学保本条件不匹配":"模型价值/覆盖率未达A、B级";
                label(box,"【"+(s2==null?"PASS":s2.grade)+"】未入选："+reason+("PASS".equals(m.aiRisk)||"C".equals(m.aiRisk)?"（AI风控降级）":""),12,WARN);
            }
            if(!m.aiNote.isEmpty())label(box,"AI/数据："+m.aiRisk+" "+m.aiNote,12,MUTED);
            LinearLayout row=horizontal(box);
            Button history=button(row,"最近7场 / 排名",()->new AlertDialog.Builder(this).setTitle(m.label())
                .setMessage("主队最近7场半场："+m.historyHome+"\n客队最近7场半场："+m.historyAway+"\n联赛排名："+m.rankHome+" / "+m.rankAway+"\n注：历史为球队视角进球-失球，非当场主客比分。")
                .setPositiveButton("关闭",null).show());
            Button change=button(row,"录入半场赔率",()->showOddsDialog(m));change.setTextColor(ACCENT);
        }
    }
    private void showOddsDialog(Match m){
        LinearLayout content=new LinearLayout(this);content.setPadding(dp(18),dp(8),dp(18),dp(8));content.setOrientation(LinearLayout.VERTICAL);
        TextView intro=label(content,"只填写 Bet365『半场正确比分』十进制赔率，不是全场比分赔率。",14,WARN);
        EditText e10=field(content,"1-0 半场赔率",m.hasOdds()?String.valueOf(m.odds[0]):"",false);
        EditText e00=field(content,"0-0 半场赔率",m.hasOdds()?String.valueOf(m.odds[1]):"",false);
        EditText e01=field(content,"0-1 半场赔率",m.hasOdds()?String.valueOf(m.odds[2]):"",false);
        new AlertDialog.Builder(this).setTitle(m.label()).setView(content).setNegativeButton("取消",null)
            .setPositiveButton("保存并重算",(d,w)->{
                try {
                    double p10=parse(val(e10),Double.NaN),p00=parse(val(e00),Double.NaN),p01=parse(val(e01),Double.NaN);
                    if(!Double.isFinite(p10)||!Double.isFinite(p00)||!Double.isFinite(p01)||Math.min(p10,Math.min(p00,p01))<=1)throw new Exception("赔率需全部大于1");
                    m.odds[0]=p10;m.odds[1]=p00;m.odds[2]=p01;m.oddsSource="用户手动输入（需自行核对 Bet365）";m.manual=true;
                    recompute(true);
                }catch(Exception ex){error(ex.getMessage());}
            }).show();
    }
    private void autoFit(){
        if(budget<=0||scanned.isEmpty()){error("请输入正数预算并先完成扫描");return;}
        int targetN=selected.size();if(targetN==0){error("没有符合条件的候选");return;}
        // Re-run exact odds and insurance math at each candidate size, rather than a linear approximation.
        long low=1,high=(long)Math.floor(baseStake);
        if(Engine.portfolio(Engine.selectTop(scanned,1,insuranceCount,target,oddsFilter),budget).total>budget){
            error("当前预算无法在每场1单位主单条件下保留全部候选；请降低场数。");return;
        }
        while(low<high){
            long mid=low+(high-low+1)/2;
            List<Engine.Selection> picks=Engine.selectTop(scanned,mid,insuranceCount,target,oddsFilter);
            double cost=Engine.portfolio(picks,budget).total;
            if(cost<=budget)low=mid;else high=mid-1;
        }
        stakeInput.setText(String.valueOf(low));
        recompute(true);
        if(portfolio!=null&&portfolio.total>budget)setStatus("预算仍可能超出：部分赔率四舍五入导致候选变化，请减少场次后重算。");
        else setStatus("已按预算重新计算主单和所有保险金额；请确认场次变化和盘口有效性。");
    }
    private void loadDemo(){
        try{parseParameters();}catch(Exception e){error(e.getMessage());return;}
        demo=true;scanned=new ArrayList<>();String[] teams={"样本A","样本B","样本C","样本D","样本E","样本F"};
        for(int i=0;i<Math.max(25,target);i++){
            Match m=new Match("demo"+i,"SIM","演示联赛（虚构）",teams[i%6]+i,teams[(i+1)%6]+i,"演示日期","NS");
            m.homeSamples=7;m.awaySamples=7;m.lambdaHome=0.48+0.07*(i%7);m.lambdaAway=0.24+0.045*(i%5);
            double[] prob=Engine.probabilities(m.lambdaHome,m.lambdaAway);
            for(int j=0;j<3;j++)m.odds[j]=Math.round((1.18/prob[j]+(i%3)*0.15)*100)/100.0;
            m.oddsSource="演示赔率（虚构，非真实 Bet365）";m.historyHome="1-0 0-0 1-0 0-0 0-1 1-0 0-0";
            m.historyAway="0-0 0-1 0-0 1-0 0-0 0-1 0-0";scanned.add(m);
        }
        setStatus("【虚构演示数据】仅验证概率、保险金额、总预算和盈亏模型。不要用于真实投注！");
        recompute(true);
    }
    private void copySummary(){
        if(portfolio==null)return;
        StringBuilder s=new StringBuilder("HT Portfolio AI 30+\n数据="+(demo?"演示":"API")+"\n入选="+selected.size()+"\n主单="+money(baseStake)+"\n保险张数="+insuranceCount+
            "\n赔率筛选="+oddsFilter.description()+"\n总投入="+money(portfolio.total)+"\n模型期望净盈亏="+money(portfolio.expectation)+"\n组合不亏概率(模拟)="+pct(portfolio.estimatedBreakevenChance)+"\n");
        for(Engine.Selection pick:selected){
            s.append("\n").append(pick.match.label()).append("\n主单 ").append(Engine.SCORES[pick.main]).append("\n");
            for(int j=0;j<3;j++)s.append(Engine.SCORES[j]).append(": odds=").append(pick.match.odds[j]).append(" stake=").append(money(pick.stakes[j])).append(" profit=").append(money(pick.profits[j])).append("\n");
            s.append("其他比分净盈亏 ").append(money(pick.profits[3])).append("\n");
        }
        clipboard(s.toString());
    }
    private void clipboard(String data){ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("HT Portfolio",data));setStatus("已复制组合报告到剪贴板。");}
    private void error(String why){new AlertDialog.Builder(this).setTitle("提示").setMessage(why).setPositiveButton("确定",null).show();}
    private static String money(double n){if(!Double.isFinite(n))return "—";return String.format(Locale.US,"%,.0f",n);}
    private static String pct(double n){return String.format(Locale.US,"%.1f%%",n*100);}
}
