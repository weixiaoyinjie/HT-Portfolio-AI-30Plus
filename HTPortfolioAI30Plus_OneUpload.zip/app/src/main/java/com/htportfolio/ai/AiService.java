package com.htportfolio.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Secondary AI risk audit, with mathematically fixed probabilities and bank calculations. */
public final class AiService {
    private AiService() {}
    public static String audit(String apiKey,List<Match> picks) throws Exception {
        if(apiKey.trim().isEmpty())return "AI 未启用（没有填写 OpenAI API Key）。当前使用历史半场进球泊松模型。";
        JSONArray data=new JSONArray();
        for(Match m:picks){
            if(!m.hasForm())continue;
            JSONObject x=new JSONObject();x.put("id",m.id);x.put("fixture",m.label());x.put("league",m.league);
            x.put("samples",m.homeSamples+"/"+m.awaySamples);x.put("rank",m.rankHome+"/"+m.rankAway);
            x.put("last7Home",m.historyHome);x.put("last7Away",m.historyAway);
            x.put("lambdaHT",new JSONArray().put(m.lambdaHome).put(m.lambdaAway));
            x.put("probability",new JSONArray(Engine.probabilities(m.lambdaHome,m.lambdaAway)));
            if(m.hasOdds())x.put("verifiedOddsHT",new JSONArray(m.odds));
            data.put(x);
        }
        if(data.length()==0)return "AI 无可核对的赛事数据。";
        String instructions="你是足球赛前风险审计，不是彩票预测。仅审查提供的比赛数据，不得虚构伤停/xG/阵容。"+
            "输出中文JSON数组，按 id 对应比赛。检查样本过小、赔率与模型概率矛盾、其他比分风险、爆冷与平局不确定性。"+
            "risk 为 PASS/C/B/A之一，note 为40字内证据分析。此结果仅作风险复核，不能擅自修改数学概率、赔率或金额。"+
            "不要保证盈利；信息不足优先PASS。";
        JSONObject schemaItem=new JSONObject().put("type","object").put("additionalProperties",false)
            .put("properties",new JSONObject().put("id",new JSONObject().put("type","string"))
            .put("risk",new JSONObject().put("type","string").put("enum",new JSONArray().put("PASS").put("C").put("B").put("A")))
            .put("note",new JSONObject().put("type","string")))
            .put("required",new JSONArray().put("id").put("risk").put("note"));
        JSONObject responseSchema=new JSONObject().put("type","object").put("additionalProperties",false)
            .put("properties",new JSONObject().put("matches",new JSONObject().put("type","array").put("items",schemaItem)))
            .put("required",new JSONArray().put("matches"));
        JSONObject request=new JSONObject();request.put("model","gpt-4.1-mini");
        request.put("instructions",instructions);
        request.put("input","请逐场复核以下资料。1-0/0-0/0-1概率顺序已知，第4项为其他比分。赔率为半场正确比分十进制赔率。\n"+data);
        request.put("max_output_tokens",7500);
        request.put("text",new JSONObject().put("format",new JSONObject().put("type","json_schema")
            .put("name","football_risk_audit").put("strict",true).put("schema",responseSchema)));
        HttpURLConnection c=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(55000);c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+apiKey.trim());
        try {
            try(java.io.OutputStream out=c.getOutputStream()){out.write(request.toString().getBytes(StandardCharsets.UTF_8));}
            int status=c.getResponseCode();InputStream in=status>=400?c.getErrorStream():c.getInputStream();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
            if(in!=null)try(in){while((n=in.read(buf))>=0){bytes.write(buf,0,n);if(bytes.size()>1_200_000)break;}}
            String text=bytes.toString(StandardCharsets.UTF_8.name());
            if(status>=400)throw new Exception("AI HTTP "+status+"："+text.substring(0,Math.min(150,text.length())));
            JSONObject doc=new JSONObject(text);JSONArray outputs=doc.optJSONArray("output");if(outputs==null)throw new Exception("AI 响应无 output");
            StringBuilder sb=new StringBuilder();
            for(int i=0;i<outputs.length();i++){
                JSONObject o=outputs.optJSONObject(i);if(o==null)continue;JSONArray content=o.optJSONArray("content");if(content==null)continue;
                for(int j=0;j<content.length();j++){
                    JSONObject item=content.optJSONObject(j);if(item!=null&&item.has("text"))sb.append(item.optString("text"));
                }
            }
            JSONObject parsed=new JSONObject(sb.toString());JSONArray risks=parsed.optJSONArray("matches");
            if(risks==null)throw new Exception("AI 输出格式异常");
            int updated=0;
            for(int i=0;i<risks.length();i++){
                JSONObject r=risks.optJSONObject(i);if(r==null)continue;
                for(Match m:picks)if(m.id.equals(r.optString("id"))){
                    String grade=r.optString("risk","C"),note=r.optString("note","");
                    if(!grade.equals("PASS")&&!grade.equals("A")&&!grade.equals("B")&&!grade.equals("C"))grade="C";
                    m.aiRisk=grade;m.aiNote=note;updated++;break;
                }
            }
            return "AI 审计完成 "+updated+" 场；AI 仅作风险降级审查，不负责赔率和本金计算。";
        } finally {c.disconnect();}
    }
}
