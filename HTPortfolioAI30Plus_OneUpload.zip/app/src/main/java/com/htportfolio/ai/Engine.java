package com.htportfolio.ai;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Deterministic calculation engine: no LLM can change stakes, settlement or scenario math. */
public final class Engine {
    private Engine() {}
    public static final String[] SCORES = {"1-0", "0-0", "0-1"};

    /** Decimal-price screen for verified Bet365 HT exact-score selections.
     *  minExclusive=3 means 3.00 is excluded and 3.01 qualifies.
     *  An unlimited upper bound uses POSITIVE_INFINITY.
     *  If allSelected is false, only the MAIN price needs to match;
     *  otherwise every proposed insured score must match as well.
     */
    public static final class OddsFilter {
        public final double minExclusive, maxInclusive;
        public final boolean allSelected;
        public OddsFilter(double minExclusive, double maxInclusive, boolean allSelected) {
            if (!Double.isFinite(minExclusive) || minExclusive < 1.0 ||
                !(Double.isFinite(maxInclusive) || maxInclusive==Double.POSITIVE_INFINITY) ||
                maxInclusive <= minExclusive)
                throw new IllegalArgumentException("赔率筛选：最小值需≥1，最大值必须大于最小值");
            this.minExclusive=minExclusive;this.maxInclusive=maxInclusive;this.allSelected=allSelected;
        }
        public boolean test(double decimalOdds) {
            return Double.isFinite(decimalOdds) && decimalOdds > minExclusive && decimalOdds <= maxInclusive;
        }
        public String description() {
            return (allSelected?"主单+保险":"仅主单")+"赔率 >"+minExclusive+
                (Double.isInfinite(maxInclusive)?"（无上限）":" 且 ≤"+maxInclusive);
        }
    }
    private static final OddsFilter NO_FILTER = new OddsFilter(1.0, Double.POSITIVE_INFINITY, false);

    public static final class Selection {
        public Match match;
        public int main;
        public final double[] probabilities = new double[4]; // three selected scores + OTHER
        public final double[] stakes = new double[3];
        public final double[] profits = new double[4];
        public double invested, expectedProfit, roi, coverage;
        public String grade, why;
        public double mainStake() { return stakes[main]; }
        public double insuranceStake() { return invested - stakes[main]; }
        public double insuranceWorst() {
            double worst=Double.POSITIVE_INFINITY;
            for (int i=0;i<3;i++) if (i!=main && stakes[i]>0) worst=Math.min(worst, profits[i]);
            return worst==Double.POSITIVE_INFINITY?Double.NaN:worst;
        }
    }

    public static void estimateForm(Match m) {
        if (m.homeSamples < 4 || m.awaySamples < 4) {
            m.lambdaHome=Double.NaN; m.lambdaAway=Double.NaN; return;
        }
        // Smoothed historical first-half goals are a proxy, NOT measured xG.
        double homeFor=(m.homeHalfFor*m.homeSamples+0.65*3.0)/(m.homeSamples+3.0);
        double homeAgainst=(m.homeHalfAgainst*m.homeSamples+0.55*3.0)/(m.homeSamples+3.0);
        double awayFor=(m.awayHalfFor*m.awaySamples+0.55*3.0)/(m.awaySamples+3.0);
        double awayAgainst=(m.awayHalfAgainst*m.awaySamples+0.65*3.0)/(m.awaySamples+3.0);
        m.lambdaHome=clamp((homeFor+awayAgainst)/2.0,0.05,2.5);
        m.lambdaAway=clamp((awayFor+homeAgainst)/2.0,0.05,2.5);
    }
    public static double clamp(double v,double min,double max) { return Math.max(min,Math.min(max,v)); }
    public static double[] probabilities(double lambdaHome,double lambdaAway) {
        if (!Double.isFinite(lambdaHome)||!Double.isFinite(lambdaAway)||lambdaHome<0||lambdaAway<0) throw new IllegalArgumentException("invalid lambda");
        double p00=Math.exp(-lambdaHome-lambdaAway),p10=p00*lambdaHome,p01=p00*lambdaAway;
        return new double[]{p10,p00,p01, Math.max(0,1-p10-p00-p01)};
    }

    /** Returns a ranked choice including PASS, or null when odds/form are not available. */
    public static Selection choose(Match m,double mainStake,int insuranceCount) {
        return choose(m,mainStake,insuranceCount,NO_FILTER);
    }
    public static Selection choose(Match m,double mainStake,int insuranceCount,OddsFilter filter) {
        if (!m.hasOdds() || !m.hasForm() || mainStake <= 0 || insuranceCount < 1 || insuranceCount > 2) return null;
        if(filter==null)filter=NO_FILTER;
        double[] p=probabilities(m.lambdaHome,m.lambdaAway);
        Selection best=null;
        for (int main=0;main<3;main++) {
            if(!filter.test(m.odds[main]))continue;
            if (insuranceCount==1) {
                for (int ins=0;ins<3;ins++) if (ins!=main) {
                    if(filter.allSelected && !filter.test(m.odds[ins]))continue;
                    Selection s=make(m,p,main,new int[]{ins},mainStake);
                    if (s!=null && s.profits[main]>0 && (best==null || s.roi>best.roi)) best=s;
                }
            } else {
                int[] ins=new int[2]; int k=0;
                for(int i=0;i<3;i++) if(i!=main) ins[k++]=i;
                if(filter.allSelected && (!filter.test(m.odds[ins[0]]) || !filter.test(m.odds[ins[1]])))continue;
                Selection s=make(m,p,main,ins,mainStake);
                if (s!=null && s.profits[main]>0 && (best==null || s.roi>best.roi)) best=s;
            }
        }
        if (best==null) return null;
        boolean confident=m.homeSamples>=7 && m.awaySamples>=7;
        if (best.roi>0.12 && best.coverage>0.63 && confident) best.grade="A";
        else if (best.roi>0.025 && best.coverage>0.55 && m.homeSamples>=5 && m.awaySamples>=5) best.grade="B";
        else if (best.roi>0) best.grade="C";
        else best.grade="PASS";
        best.why=String.format(Locale.US,"估计覆盖率 %.1f%%｜模型EV %.1f%%｜半场历史 %d/%d 场｜其他比分概率 %.1f%%",
                best.coverage*100,best.roi*100,m.homeSamples,m.awaySamples,p[3]*100);
        return best;
    }

    private static Selection make(Match m,double[] p,int main,int[] ins,double mainStake) {
        Selection s=new Selection(); s.match=m; s.main=main;
        System.arraycopy(p,0,s.probabilities,0,4);
        s.stakes[main]=Math.ceil(mainStake);
        if(ins.length==1) {
            int i=ins[0];
            s.stakes[i]=Math.ceil(s.stakes[main]/(m.odds[i]-1.0));
        } else {
            int i=ins[0],j=ins[1];
            double denom=1-1/m.odds[i]-1/m.odds[j];
            if (denom<=0.000001) return null; // mathematical break even impossible
            double t=s.stakes[main]/denom;
            s.stakes[i]=Math.ceil(t/m.odds[i]);
            s.stakes[j]=Math.ceil(t/m.odds[j]);
            // Integer-unit rounding sometimes damages one side's hedge; correct it.
            for(int iter=0;iter<2000;iter++) {
                double total=s.stakes[0]+s.stakes[1]+s.stakes[2];
                double pI=s.stakes[i]*m.odds[i]-total;
                double pJ=s.stakes[j]*m.odds[j]-total;
                if (pI>=-1e-6 && pJ>=-1e-6) break;
                if(pI<0) s.stakes[i]+=Math.ceil((-pI)/(m.odds[i]-1))+1;
                else s.stakes[j]+=Math.ceil((-pJ)/(m.odds[j]-1))+1;
                if(iter==1999) return null;
            }
        }
        for(double stake:s.stakes) s.invested+=stake;
        if (s.invested>1e12) return null;
        for(int i=0;i<3;i++) s.profits[i]=s.stakes[i]>0 ? s.stakes[i]*m.odds[i]-s.invested : -s.invested;
        s.profits[3]=-s.invested;
        for(int i:ins) if (s.profits[i] < -0.01) return null;
        for(int i=0;i<4;i++) s.expectedProfit+=s.probabilities[i]*s.profits[i];
        s.roi=s.expectedProfit/s.invested;
        s.coverage=0;
        for (int i=0;i<3;i++) if(s.stakes[i]>0) s.coverage+=p[i];
        return s;
    }

    /** Preserve an existing main / insurance choice while repricing for a new total budget. */
    public static Selection reprice(Selection original,double newMain) {
        if(original==null || newMain<=0)return null;
        int count=0;for(int i=0;i<3;i++)if(i!=original.main&&original.stakes[i]>0)count++;
        int[] ins=new int[count];int k=0;
        for(int i=0;i<3;i++)if(i!=original.main&&original.stakes[i]>0)ins[k++]=i;
        Selection s=make(original.match,original.probabilities,original.main,ins,newMain);
        if(s!=null){s.grade=original.grade;s.why=original.why;}
        return s;
    }

    public static List<Selection> selectTop(List<Match> matches,double mainStake,int ins,int target) {
        return selectTop(matches,mainStake,ins,target,NO_FILTER);
    }
    public static List<Selection> selectTop(List<Match> matches,double mainStake,int ins,int target,OddsFilter filter) {
        List<Selection> selections=new ArrayList<>();
        for(Match m:matches) {
            Selection s=choose(m,mainStake,ins,filter);
            if(s!=null && ("A".equals(s.grade)||"B".equals(s.grade)) && !"PASS".equals(m.aiRisk) && !"C".equals(m.aiRisk)) selections.add(s);
        }
        selections.sort(Comparator.comparingDouble((Selection s)->s.roi).reversed());
        return new ArrayList<>(selections.subList(0,Math.min(target,selections.size())));
    }

    public static final class Portfolio {
        public int n, mainCount, backupCount;
        public double budget,total,expectation,bestCase,worstCase,suggestedMain,maxMainRisk;
        public double estimatedBreakevenChance,p05,p50,p95;
        public double[][] minimum,maximum; // exact extrema conditional on (#main wins, #insurance wins)
        public int possibleOutcomes;
        public double min(int main,int insurance) { return valid(main,insurance) ? minimum[main][insurance] : Double.NaN; }
        public double max(int main,int insurance) { return valid(main,insurance) ? maximum[main][insurance] : Double.NaN; }
        private boolean valid(int main,int insurance) { return main>=0 && insurance>=0 && main<n+1 && insurance<n+1-main; }
    }

    public static Portfolio portfolio(List<Selection> list,double budget) {
        Portfolio out=new Portfolio();out.n=list.size();out.budget=budget;
        int n=out.n;
        double infinity=Double.POSITIVE_INFINITY;
        double[][] lo=new double[n+1][n+1],hi=new double[n+1][n+1];
        for(int i=0;i<=n;i++) { Arrays.fill(lo[i],infinity);Arrays.fill(hi[i],-infinity); }
        lo[0][0]=0;hi[0][0]=0;
        double coef=0;
        for (int k=0;k<n;k++) {
            Selection s=list.get(k);out.total+=s.invested;out.expectation+=s.expectedProfit;
            coef += s.invested/s.mainStake();
            out.bestCase+=Arrays.stream(s.profits).max().orElse(0);
            out.worstCase-=s.invested;
            double[][] nextLo=new double[n+1][n+1],nextHi=new double[n+1][n+1];
            for(int i=0;i<=n;i++) { Arrays.fill(nextLo[i],infinity);Arrays.fill(nextHi[i],-infinity); }
            for(int m=0;m<=k;m++) for(int b=0;b<=k-m;b++) {
                if (!Double.isFinite(lo[m][b])) continue;
                for (int outcome=0;outcome<4;outcome++) {
                    if(outcome<3 && s.stakes[outcome]==0) continue;
                    int mm=m+(outcome==s.main?1:0);
                    int bb=b+(outcome<3&&outcome!=s.main?1:0);
                    nextLo[mm][bb]=Math.min(nextLo[mm][bb],lo[m][b]+s.profits[outcome]);
                    nextHi[mm][bb]=Math.max(nextHi[mm][bb],hi[m][b]+s.profits[outcome]);
                }
            }
            lo=nextLo;hi=nextHi;
        }
        out.minimum=lo;out.maximum=hi;
        out.suggestedMain=coef>0?Math.floor(budget/coef):0;
        out.maxMainRisk=coef;
        if (n>0) monteCarlo(list,out,12000);
        return out;
    }

    private static void monteCarlo(List<Selection> picks,Portfolio out,int trials) {
        // Independent-match assumption; this is an estimate, not a guaranteed probability.
        Random random=new Random(20261022L);
        double[] profits=new double[trials];int nonLoss=0;
        for(int it=0;it<trials;it++) {
            double result=0;
            for(Selection s:picks) {
                double draw=random.nextDouble(),sum=0;
                int outcome=3;
                for(int j=0;j<3;j++) { sum+=s.probabilities[j];if(draw<sum){outcome=j;break;} }
                result+=s.profits[outcome];
            }
            profits[it]=result;if(result>=-0.005)nonLoss++;
        }
        Arrays.sort(profits);
        out.estimatedBreakevenChance=nonLoss/(double)trials;
        out.p05=profits[(int)(0.05*(trials-1))];out.p50=profits[(int)(0.50*(trials-1))];out.p95=profits[(int)(0.95*(trials-1))];
    }
}
