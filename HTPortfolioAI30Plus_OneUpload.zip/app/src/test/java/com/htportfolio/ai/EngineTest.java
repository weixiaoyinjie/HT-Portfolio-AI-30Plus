package com.htportfolio.ai;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

public class EngineTest {
    private Match match() {
        Match m=new Match("x","ES","La Liga","A","B","20:00","NS");
        m.lambdaHome=0.75;m.lambdaAway=0.40;
        m.homeSamples=7;m.awaySamples=7;
        m.odds[0]=5.5;m.odds[1]=4.1;m.odds[2]=9.0;
        return m;
    }
    @Test public void probabilitySum() {
        double s=0;for(double p:Engine.probabilities(0.7,0.4))s+=p;
        assertEquals(1,s,1e-10);
    }
    @Test public void insuranceOneBreakEven() {
        Match m=match();Engine.Selection s=Engine.choose(m,10000,1);
        assertNotNull(s);
        for(int i=0;i<3;i++) if(i!=s.main && s.stakes[i]>0) assertTrue(s.profits[i]>=-0.01);
        assertEquals(-s.invested,s.profits[3],1e-7);
    }
    @Test public void insuranceTwoBreakEven() {
        Match m=match();Engine.Selection s=Engine.choose(m,10000,2);
        assertNotNull(s);
        for(int i=0;i<3;i++) if(i!=s.main)assertTrue(s.profits[i]>=-0.01);
    }
    @Test public void repricePreservesCoveredOutcomes() {
        Engine.Selection before=Engine.choose(match(),10000,2);
        Engine.Selection after=Engine.reprice(before,5500);
        assertNotNull(after);
        assertEquals(5500,after.mainStake(),0.001);
        for(int i=0;i<3;i++) if(i!=after.main && after.stakes[i]>0)
            assertTrue(after.profits[i]>=-0.01);
    }
    @Test public void selectedProbabilitiesIncludeOtherScore() {
        Match m=match();Engine.Selection s=Engine.choose(m,10000,2);
        assertTrue(s.probabilities[3]>0);
        assertTrue(s.profits[3]<0);
        double ev=0;for(int i=0;i<4;i++)ev+=s.probabilities[i]*s.profits[i];
        assertEquals(ev,s.expectedProfit,0.0001);
    }
    @Test public void mathematicallyImpossibleHedge() {
        Match m=match();m.odds[0]=2.0;m.odds[1]=2.0;m.odds[2]=2.0;
        assertNull(Engine.choose(m,10000,2));
    }
    @Test public void exactScenarioExtrema() {
        Match m=match();Engine.Selection a=Engine.choose(m,10000,1);
        Engine.Portfolio p=Engine.portfolio(Arrays.asList(a,a),30000);
        assertEquals(2,p.n);
        assertEquals(-p.total,p.min(0,0),0.001);
        assertEquals(-p.total,p.max(0,0),0.001);
        assertEquals(2*a.profits[a.main],p.min(2,0),0.001);
        assertTrue(p.max(0,2)>=-0.01);
    }
    @Test public void oddsStrictlyGreaterThanThree() {
        Engine.OddsFilter f=new Engine.OddsFilter(3.0, 8.0, false);
        assertFalse(f.test(3.0));
        assertTrue(f.test(3.01));
        assertTrue(f.test(8.0));
        assertFalse(f.test(8.01));
    }
    @Test public void configurableMainOddsFilter() {
        Match m=match();
        Engine.OddsFilter aboveEight=new Engine.OddsFilter(8.0,Double.POSITIVE_INFINITY,false);
        Engine.Selection onlyHigh=Engine.choose(m,10000,1,aboveEight);
        if(onlyHigh!=null) assertEquals(2,onlyHigh.main);
        Engine.OddsFilter impossibleAll=new Engine.OddsFilter(8.0,20.0,true);
        assertNull(Engine.choose(m,10000,2,impossibleAll));
    }
    @Test public void rejectsInvalidBounds() {
        try {new Engine.OddsFilter(3.0,3.0,false);fail("bounds");}
        catch(IllegalArgumentException expected) { /* expected */ }
    }
}
